# MancaBot
Only Termux
<h1 align="center">𝙉𝙐𝙍𝙐𝙇ツ<img src="https://user-images.githubusercontent.com/1303154/88677602-1635ba80-d120-11ea-84d8-d263ba5fc3c0.gif" width="40px" alt="hi"><br>Nurul Manca Was Hare!</h1>

<p align="center">
<img src="https://ibb.co/r5wpr0n" width="100%" alt="API Giphy logo"/>
</p>

- 🌱 I’m currently learning **nothing**.

- 👀 I m currently focusing on **JavaScript**.


<p align="center">
  <img src="https://img.shields.io/badge/-JavaScript-black?style=flat-square&logo=javascript" />
  <img src="https://img.shields.io/badge/-Node.js-black?style=flat-square&logo=Node.js" />
  <img src="https://img.shields.io/badge/-HTML5-black?style=flat-square&logo=html5&logoColor=e34f26" />
  <img src="https://img.shields.io/badge/-CSS3-black?style=flat-square&logo=css3&logoColor=1572b6" />
  <img src="https://img.shields.io/badge/-Git-black?style=flat-square&logo=git" />
  <img src="https://img.shields.io/badge/-GitHub-black?style=flat-square&logo=github" /> <br>
  <img src="https://img.shields.io/badge/-Python-black?style=flat-square&logo=python" />
  <img src="https://img.shields.io/badge/-React-black?style=flat-square&logo=react" />
  <img src="https://img.shields.io/badge/-Redux-black?style=flat-square&logo=redux" />
  <img src="https://img.shields.io/badge/-Windows-black?style=flat-square&logo=windows" />
  <img src="https://img.shields.io/badge/-VS_Code-black?style=flat-square&logo=visual-studio-code" />
  <img src="https://img.shields.io/badge/-SQLite3-black?style=flat-square&logo=sqlite" />
</p>

<p align="center">
  <a href="https://github.com/mancabot"><img src="https://github-readme-stats.vercel.app/api?username=mancabot&bg_color=30,e96443,904e95&title_color=fff&text_color=fff&icon_color=fff&hide_border=true&show_icons=true" /></a>
</p>

<p align="center">
  <a href="https://github.com/mancabot"><img src="https://github-readme-stats.vercel.app/api/top-langs?username=mancabot&bg_color=30,e96443,904e95&title_color=fff&text_color=fff&hide_border=true&show_icons=true&layout=compact" /></a>
</p>

<p align="center">
  <a href="https://github.com/ryo-ma/github-profile-trophy"><img src="https://github-profile-trophy.vercel.app/?username=mancabot&theme=onedark" /></a>
</p>

<p align="center">
   <img src="https://github-readme-streak-stats.herokuapp.com/?user=mancabot" />
</p>

<p align="center">
  <a href="https://youtu.be/n9fUrhPf5-8"><img src="https://img.shields.io/badge/YouTube-SofyanAMV09-ff0000?style=for-the-badge&logo=youtube&logoColor=ff0000&lihttps://youtu.be/n9fUrhPf5-8-8" /></a>
  <a name=hendra759&label=VIEWS&style=flat-square&color=orange" />

## Install the dependencies:
Before running the below command, make sure you're in the project directory that
you've just cloned!!

```bash
> pkg update && pkg upgrade 
> pkg install nodejs
> pkg install tesseract 
> git clone https://github.com/alonecans/wansap-bot-manca
> cd wansap-bot-manca
> bash install.sh
```

### Usage
```bash
> npm start
```

</p> 
 #sosial media


* [`WhatsApp Admin `](https://wa.me/6283815956151)

* [`Chika Bot `](https://wa.me/994404762586)


